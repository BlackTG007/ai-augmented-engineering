# DE Team Coding Standards

<!-- Add your six DE coding standards below this line -->
